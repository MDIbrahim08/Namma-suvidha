---
name: Civic Telemetry & Navigation
colors:
  surface: '#f9f9fb'
  surface-dim: '#d9dadc'
  surface-bright: '#f9f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f5'
  surface-container: '#edeef0'
  surface-container-high: '#e7e8ea'
  surface-container-highest: '#e1e2e4'
  on-surface: '#191c1d'
  on-surface-variant: '#41484c'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f3'
  outline: '#71787d'
  outline-variant: '#c0c7cd'
  surface-tint: '#30647b'
  primary: '#003244'
  on-primary: '#ffffff'
  primary-container: '#0c4a60'
  on-primary-container: '#86b9d2'
  inverse-primary: '#9acee8'
  secondary: '#006398'
  on-secondary: '#ffffff'
  secondary-container: '#5bb8fe'
  on-secondary-container: '#00476e'
  tertiary: '#452700'
  on-tertiary: '#ffffff'
  tertiary-container: '#613c0d'
  on-tertiary-container: '#dca76f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bfe9ff'
  primary-fixed-dim: '#9acee8'
  on-primary-fixed: '#001f2a'
  on-primary-fixed-variant: '#104c63'
  secondary-fixed: '#cce5ff'
  secondary-fixed-dim: '#93ccff'
  on-secondary-fixed: '#001d31'
  on-secondary-fixed-variant: '#004b73'
  tertiary-fixed: '#ffdcbc'
  tertiary-fixed-dim: '#f3bc82'
  on-tertiary-fixed: '#2c1700'
  on-tertiary-fixed-variant: '#643e0f'
  background: '#f9f9fb'
  on-background: '#191c1d'
  surface-variant: '#e1e2e4'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
  telemetry-code:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes a high-precision, navigational-grade interface for public infrastructure and civic utilities. Inspired by nautical cartography and marine telemetry consoles, the visual tone balances civic authority with effortless spatial orientation.

### Character & Attributes
- **Nautical Precision:** Utilitarian clarity derived from maritime chart plotters; zero clutter, maximum signal-to-noise ratio, and clear geometric hierarchy.
- **Civic Trust:** Dependable, unembellished, and authoritative without feeling bureaucratic.
- **Map-First Spatial Ergonomics:** UI surfaces float decisively over dynamic cartographic canvases using distinct glass scrims, crisp structural borders, and calibrated elevation.

### Design Language
A hybrid of **Modern Minimalist Telemetry** and **Refined Floating Instrument Panels**. The style uses high-contrast vector geometry, pill-shaped control clusters, tactile status beacons, micro-borders for structural containment, and legible sans-serif typography engineered for rapid glanceability under varying field conditions.

## Colors

The palette leverages deep maritime teals and technical cyans for operational structure, paired with high-consequence civic status accents designed for instantaneous recognition against map layers.

### Palette Architecture

- **Primary (`#0c4a60` — Deep Trust Navy Teal):** Anchors core actions, navigation headers, primary route pathways, and commanding UI surfaces.
- **Secondary (`#0284c7` — Navigational Cerulean):** Powers active waypoints, focal telemetry pins, telemetry tracking, and dynamic interactive selections.
- **Tertiary (`#10b981` — Verified Emerald):** Signals pristine infrastructure, verified civic completions, open municipal assets, and safe passage.
- **Warning (`#f59e0b` — Safety Amber):** Denotes maintenance zones, cautionary transit buffers, pending utility reports, and advisory telemetry.
- **Critical Alert (`#ef4444` — Alert Coral):** Represents immediate civic hazards, emergency road blockages, critical pipeline disruptions, and urgent reporting states.
- **Neutral Canvas & Surfaces:**
  - *Light Mode:* Base canvas set at `#f8fafc` (Ultra-Crisp Slate White), with `#ffffff` for floating instrumentation cards and `#e2e8f0` for hairline borders.
  - *Dark Mode:* Deep nautical slate (`#0f172a`) with elevated console layers in marine graphite (`#1e293b`), bounded by `#334155` technical outlines.

## Typography

The typographic hierarchy is built on geometric clarity and high legibility across dynamic map viewports.

- **Headlines & Primary Copy (Plus Jakarta Sans):** Selected for its contemporary geometric balance, open counters, and human-centric tone, ensuring effortless legibility in headers, wayfinding titles, and card surfaces.
- **Labels, Telemetry, and Micro-Data (Inter):** Engineered for rigorous pixel grids. Applied to GPS coordinates, distance markers, status indicators, and compact pill controllers where tabular legibility and anti-aliasing sharpness are critical.
- **Telemetry Figures:** All numerical readings (speeds, distances, ETA counts, tracking numbers) must render with tabular figures (`font-variant-numeric: tabular-nums`) to prevent layout shifts during live data polling.

## Layout & Spacing

Layouts are designed with a **Map-Centric Layering Model** that prioritizes an unobstructed viewport while keeping critical telemetry controls accessible.

### Structure & Grids
- **Base Canvas:** The interactive map remains the continuous baseline canvas (`z-index: 0`).
- **Floating Overlays:** Interface elements sit inside floating containment clusters with perimeter safe margins (`margin` on mobile, scaling to `margin-desktop`).
- **Desktop Grid:** A 12-column fluid grid system with `gutter-desktop` (24px) spacing, docked inside maximum viewport widths of 1440px for desktop console dashboards.
- **Mobile Grid:** Single-column floating modular sheet pattern; bottom-aligned docking sheet with a top floating telemetry pill cluster.

### Spacing Principles
- Spatial rhythm adheres to a strict 4px/8px modular base.
- Internal component spacing uses `space-xs` (4px) and `space-sm` (8px) for compact telemetry clusters, while `space-md` (16px) controls primary card and modal inner padding.

## Elevation & Depth

Visual hierarchy uses **floating instrument surfaces** over continuous mapping layers, achieved through a combination of backdrop blurs, technical hairline borders, and tinted navigational shadows.

### Surface Tiers

1. **Map Ground Layer (Elevation 0):** Cartographic background, vector streets, bathymetric/civic zone fills.
2. **Telemetry Scrim Layer (Elevation 1):**
   - Translucent frosted glass for floating pills and toolbars (`rgba(255, 255, 255, 0.88)` in light mode, `rgba(15, 23, 42, 0.82)` in dark mode).
   - Backdrop filter: `blur(12px) saturate(180%)`.
   - Shadow: `0 2px 8px -2px rgba(12, 74, 96, 0.08), 0 1px 3px rgba(0, 0, 0, 0.04)`.
   - Structural Outline: 1px continuous border with `rgba(12, 74, 96, 0.12)` in light mode and `rgba(255, 255, 255, 0.1)` in dark mode.
3. **Interactive Cards & Drawer Consoles (Elevation 2):**
   - Solid functional cards hosting issue tickets, service routes, and telemetry metrics.
   - Shadow: `0 10px 25px -5px rgba(12, 74, 96, 0.12), 0 4px 10px -2px rgba(12, 74, 96, 0.06)`.
   - Dark Mode Shadow: `0 12px 30px -4px rgba(0, 0, 0, 0.45)`.
4. **Emergency Overlays & Beacons (Elevation 3):**
   - Floating urgent warnings and active navigation sheets.
   - Shadow: `0 20px 40px -8px rgba(15, 23, 42, 0.22)`.
   - Emits an ambient localized glow when paired with warning/alert beacons (e.g., `0 0 16px rgba(239, 68, 68, 0.3)` for alert coral).

## Shapes

The shape system balances **capsule pill controls** for mobile interaction with **calibrated rounded rectangles** for high-density information cards.

- **Primary Cards & Containers (`rounded-lg` / 16px):** Used for bottom sheets, telemetry dashboards, civic report cards, and modal dialogs to balance modern softness with space efficiency.
- **Interactive Pill Clusters (`rounded-full` / 9999px):** All floating map controls (zoom, layer switchers, quick filter chips, and primary dispatch buttons) use continuous capsule silhouettes for finger-friendly targets and distinct visual separation from sharp map geometry.
- **Nested Elements (`rounded-md` / 8px):** Internal input fields, icon badges, and secondary list items mirror exterior radii proportionally.

## Components

### Buttons & Pill Controls
- **Primary Telemetry Button:** Rounded pill shape, filled with `#0c4a60` (Primary Teal), crisp white typography (`label-lg`), and an embedded directional line icon. Hover transitions to `#0284c7`.
- **Floating Action Pills:** Height: 44px (touch target: 48px min). Translucent background with a 1px technical border and backdrop blur. Houses single-purpose toggles (e.g., "Recenter Map", "Toggle Layers").
- **Secondary Civic Action:** Flat surface using `rgba(2, 132, 199, 0.1)` background with `#0284c7` text and active scale feedback (`scale(0.98)`).

### Status Beacons & Chips
- **Telemetry Status Badges:** Compact capsule pills with a living status indicator dot. Dot includes an ambient 2px outer ping for live tracking.
  - *Clean / Verified:* `#10b981` background tint (`15%` opacity) with `#065f46` text and emerald beacon.
  - *Advisory / Pending:* `#f59e0b` tint (`15%` opacity) with `#92400e` text and safety amber beacon.
  - *Critical Disruption:* `#ef4444` tint (`15%` opacity) with `#991b1b` text and alert coral beacon.

### Cards & Telemetry Sheets
- **Floating Utility Cards:** Contained within `rounded-lg` (16px) boundaries, built with 1px hairline borders (`#e2e8f0` light / `#334155` dark). Dividers use subtle inset borders. Cards contain clear navigational breadcrumbs and telemetry key-value pairs rendered in `label-sm` with tabular numerals.
- **Bottom Drawers:** Multi-stage drawer with a distinct pill handle bar (36px width, 4px height, `#94a3b8`). Smooth transition curves (`cubic-bezier(0.16, 1, 0.3, 1)`).

### Input Fields & Search Bars
- **Floating Map Search:** Pill-shaped input bar floating top-center. Houses a leading compass or search icon, bold placeholder text in `body-md`, and a trailing quick-action micro-chip for GPS geolocation.
- **Field Inputs:** High-contrast bordered inputs with 1.5px focus rings in Cerulean (`#0284c7`), without default browser shadows.

### Checkboxes, Radios & Switches
- **Toggles:** Pill-shaped toggle switches resembling marine control switches with smooth sliding action, utilizing `#0284c7` for active states and `#cbd5e1` for inactive states.
- **Selection Checks:** Minimalist square rings with rounded corners (4px), using emerald fills on completion for clean civic verification states.

### Specialized Utility Components
- **Telemetry HUD Strip:** Ultra-condensed horizontal indicator bar pinned to card bottoms displaying real-time utility metrics (e.g., "LAT/LONG", "SIGNAL: ACCURATE TO 2M", "STATUS: RESOLVED") using the `telemetry-code` typographic token.